import boto3

def custom_metric(event, lambda_context):
    cloudwatch = boto3.client('cloudwatch')

    cloudwatch.put_metric_data(
        MetricData = [
            {
                'MetricName': 'luna_fraud_check_metric_for_vip_user',
                'Dimensions': [
                    {
                        'Name': 'fraud_choice',
                        'Value': 'lottery_recommend_number_include_13'
                    }
                ],
                'Unit': 'None',
                'Value': 1
            },
        ],
        Namespace='Luna'
    )

    return "~ Adding custom metric to cloudwatch successful ~ "



