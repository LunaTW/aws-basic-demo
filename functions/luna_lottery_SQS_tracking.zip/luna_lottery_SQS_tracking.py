import boto3
import json

def sqs_tracking_log(event, context):
    # 1. receive message from sqs. 2. send email to public user.

    # Create a new SES resource and specify a region.
    client = boto3.client('ses')

    for record in event['Records']:
        print("=========== From SQS: ===========")
        payload = record["body"]
        print(str(payload))

        response = client.send_email(
            Source = "example@163.com",
            Destination={
                'ToAddresses': [
                    "example@163.com",
                ]
            },
            Message={
                'Subject': {
                    'Data': "emaiL_subject"
                },
                'Body': {
                    'Text': {
                        'Data': "email_body"
                    }
                }
            }
        )